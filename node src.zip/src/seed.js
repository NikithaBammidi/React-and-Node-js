

const pool = require('./db'); 

async function seedDatabase() {
  try {
    const query = `
      INSERT INTO customers (customer_name, age, phone, location, created_at)
      VALUES
        ('John Doe', 25, '1234567890', 'New York', NOW()),
        ('Jane Smith', 30, '2345678901', 'Los Angeles', NOW()),
        ('Alice Johnson', 35, '3456789012', 'Chicago', NOW()),
        ('Bob Brown', 40, '4567890123', 'Houston', NOW()),
        ('Emily Davis', 45, '5678901234', 'Phoenix', NOW()),
        ('Michael Wilson', 50, '6789012345', 'Philadelphia', NOW()),
        ('Jessica Lee', 55, '7890123456', 'San Antonio', NOW()),
        ('William Martinez', 60, '8901234567', 'San Diego', NOW()),
        ('Sophia Taylor', 65, '9012345678', 'Dallas', NOW()),
        ('Daniel Anderson', 70, '0123456789', 'San Jose', NOW()),
        ('Olivia Thomas', 25, '1234567890', 'New York', NOW()),
        ('James White', 30, '2345678901', 'Los Angeles', NOW()),
        ('Sophia Johnson', 35, '3456789012', 'Chicago', NOW()),
        ('Alexander Garcia', 40, '4567890123', 'Houston', NOW()),
        ('Emma Martinez', 45, '5678901234', 'Phoenix', NOW()),
        ('Benjamin Rodriguez', 50, '6789012345', 'Philadelphia', NOW()),
        ('Ava Hernandez', 55, '7890123456', 'San Antonio', NOW()),
        ('Mason Lopez', 60, '8901234567', 'San Diego', NOW()),
        ('Isabella Gonzalez', 65, '9012345678', 'Dallas', NOW()),
        ('Ethan Perez', 70, '0123456789', 'San Jose', NOW()),
        ('Mia Smith', 25, '1234567890', 'New York', NOW()),
        ('Liam Johnson', 30, '2345678901', 'Los Angeles', NOW()),
        ('Charlotte Brown', 35, '3456789012', 'Chicago', NOW()),
        ('Noah Davis', 40, '4567890123', 'Houston', NOW()),
        ('Amelia Wilson', 45, '5678901234', 'Phoenix', NOW()),
        ('Elijah Lee', 50, '6789012345', 'Philadelphia', NOW()),
        ('Harper Martinez', 55, '7890123456', 'San Antonio', NOW()),
        ('Aiden Taylor', 60, '8901234567', 'San Diego', NOW()),
        ('Avery Anderson', 65, '9012345678', 'Dallas', NOW()),
        ('Mason Garcia', 70, '0123456789', 'San Jose', NOW()),
        ('Ella Taylor', 25, '1234567890', 'New York', NOW()),
        ('Logan Martinez', 30, '2345678901', 'Los Angeles', NOW()),
        ('Mia Johnson', 35, '3456789012', 'Chicago', NOW()),
        ('Lucas Garcia', 40, '4567890123', 'Houston', NOW()),
        ('Aria Hernandez', 45, '5678901234', 'Phoenix', NOW()),
        ('Ethan Lopez', 50, '6789012345', 'Philadelphia', NOW()),
        ('Luna Gonzalez', 55, '7890123456', 'San Antonio', NOW()),
        ('Liam Perez', 60, '8901234567', 'San Diego', NOW()),
        ('Scarlett Rodriguez', 65, '9012345678', 'Dallas', NOW()),
        ('Carter Smith', 70, '0123456789', 'San Jose', NOW()),
        ('Sophia Moore', 25, '1234567890', 'New York', NOW()),
        ('Aiden Davis', 30, '2345678901', 'Los Angeles', NOW()),
        ('Ella Wilson', 35, '3456789012', 'Chicago', NOW()),
        ('Jackson Taylor', 40, '4567890123', 'Houston', NOW()),
        ('Amelia Brown', 45, '5678901234', 'Phoenix', NOW()),
        ('Liam Johnson', 50, '6789012345', 'Philadelphia', NOW()),
        ('Olivia Martinez', 55, '7890123456', 'San Antonio', NOW()),
        ('Noah Anderson', 60, '8901234567', 'San Diego', NOW()),
        ('Isabella Lee', 65, '9012345678', 'Dallas', NOW()),
        ('Mason Rodriguez', 70, '0123456789', 'San Jose', NOW())
    `;
    
 
    await pool.query(query);
    
    console.log('Dummy data inserted successfully');
  } catch (error) {
    console.error('Error seeding database:', error.message);
  } finally {

    pool.end();
  }
}

seedDatabase();
