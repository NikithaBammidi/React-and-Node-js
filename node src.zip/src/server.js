const express = require('express');
const { Pool } = require('pg');

const app = express();
const port = 3001; // Choose a port for your backend server

// PostgreSQL database connection configuration
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'postgres',
  password: 'teja',
  port: 5432,
});

// Define API endpoint to fetch data with pagination and sorting
app.get('/api/customers', async (req, res) => {
  try {
    const { page = 1, sortBy = 'created_at', search = '' } = req.query;
    const pageSize = 20;
    const offset = (page - 1) * pageSize;

    let query = `
      SELECT customer_name, age, phone, location, created_at::date AS date, created_at::time AS time
      FROM customers
    `;

    if (search) {
      query += ` WHERE customer_name ILIKE '%${search}%' OR location ILIKE '%${search}%'`;
    }

    query += `
      ORDER BY ${sortBy}
      LIMIT ${pageSize} OFFSET ${offset};
    `;

    const result = await pool.query(query);
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching data:', error.message);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
