declare module 'chunky'
